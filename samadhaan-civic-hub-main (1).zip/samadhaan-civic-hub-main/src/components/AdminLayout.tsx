import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, FileText, Clock, CheckCircle, Users, Building2, 
  Settings, AlertTriangle, ClipboardList, Wrench, Menu, X, Bell, LogOut
} from 'lucide-react';
import emblem from '@/assets/emblem.png';

const navItems = [
  { title: 'Dashboard', path: '/', icon: LayoutDashboard },
  { title: 'All Issues', path: '/issues', icon: FileText },
  { title: 'Pending Verification', path: '/pending', icon: AlertTriangle },
  { title: 'Assigned Issues', path: '/assigned', icon: ClipboardList },
  { title: 'In Progress', path: '/in-progress', icon: Wrench },
  { title: 'Resolved Issues', path: '/resolved', icon: CheckCircle },
  { title: 'User Management', path: '/users', icon: Users },
  { title: 'Departments', path: '/departments', icon: Building2 },
  { title: 'Admin Profile', path: '/profile', icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const location = useLocation();

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-foreground/50 z-20 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-30 w-64 gov-gradient text-sidebar-foreground flex flex-col transition-transform duration-200 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0 lg:w-0 lg:overflow-hidden'}`}>
        <div className="p-4 flex items-center gap-3 border-b border-sidebar-border">
          <img src={emblem} alt="Government Emblem" className="h-10 w-10 object-contain" />
          <div>
            <h1 className="text-sm font-bold tracking-wide text-sidebar-foreground">SAMADHAAN</h1>
            <p className="text-[10px] text-sidebar-foreground/70">Smart Civic Issue Management</p>
          </div>
        </div>
        <nav className="flex-1 py-4 overflow-y-auto">
          {navItems.map(item => {
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-2.5 mx-2 rounded-md text-sm transition-colors ${active ? 'bg-sidebar-accent text-saffron font-semibold' : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                <span>{item.title}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-sidebar-border">
          <Link to="/login" className="flex items-center gap-2 text-sm text-sidebar-foreground/70 hover:text-sidebar-foreground">
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-14 bg-card border-b flex items-center justify-between px-4 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1.5 rounded-md hover:bg-muted">
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div className="h-6 w-1 rounded-full bg-saffron" />
            <span className="text-sm font-semibold text-foreground hidden sm:block">SAMADHAAN Admin Panel</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-1.5 rounded-md hover:bg-muted">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-destructive text-destructive-foreground text-[10px] flex items-center justify-center">3</span>
            </button>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">AD</div>
              <span className="text-sm font-medium hidden sm:block">Admin</span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
