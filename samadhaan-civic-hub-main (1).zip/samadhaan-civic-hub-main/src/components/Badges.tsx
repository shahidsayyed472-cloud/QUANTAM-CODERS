import { Priority } from '@/data/mockData';

export function PriorityBadge({ priority }: { priority: Priority }) {
  const config: Record<Priority, { emoji: string; cls: string }> = {
    'High': { emoji: '🔴', cls: 'priority-high' },
    'Medium': { emoji: '🟠', cls: 'priority-medium' },
    'Low': { emoji: '🟡', cls: 'priority-low' },
    'Very Low': { emoji: '🟢', cls: 'priority-verylow' },
  };
  const c = config[priority];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${c.cls}`}>
      {c.emoji} {priority}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    'Submitted': 'bg-muted text-muted-foreground',
    'Verified': 'bg-primary/10 text-primary',
    'Assigned': 'bg-saffron/20 text-foreground',
    'Work In Progress': 'bg-saffron/30 text-foreground',
    'Resolved': 'bg-gov-green/20 text-gov-green',
    'Rejected': 'bg-destructive/10 text-destructive',
    'Fake': 'bg-destructive/20 text-destructive',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colors[status] || 'bg-muted text-muted-foreground'}`}>
      {status}
    </span>
  );
}
