import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import emblem from '@/assets/emblem.png';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        {/* Tri-color stripe */}
        <div className="flex h-1.5 rounded-t-lg overflow-hidden">
          <div className="flex-1 bg-saffron" />
          <div className="flex-1 bg-card" />
          <div className="flex-1 bg-gov-green" />
        </div>
        <div className="bg-card rounded-b-lg shadow-lg border p-8">
          <div className="flex flex-col items-center mb-6">
            <img src={emblem} alt="Government Emblem" className="h-20 w-20 object-contain mb-4" />
            <h1 className="text-xl font-bold text-foreground tracking-wide">SAMADHAAN</h1>
            <p className="text-xs text-muted-foreground mt-1">ADMIN PANEL</p>
            <p className="text-[10px] text-muted-foreground">Smart Civic Issue Reporting & Management System</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-md border bg-background text-foreground text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                placeholder="admin@samadhaan.gov.in"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-md border bg-background text-foreground text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                placeholder="••••••••"
              />
            </div>
            <button type="submit" className="w-full py-2.5 rounded-md bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">
              Login to Admin Panel
            </button>
          </form>

          <p className="text-center text-[10px] text-muted-foreground mt-6">
            Government of India • Ministry of Urban Development
          </p>
        </div>
      </div>
    </div>
  );
}
