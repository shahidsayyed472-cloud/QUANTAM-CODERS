import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter } from 'lucide-react';
import AdminLayout from '@/components/AdminLayout';
import { PriorityBadge, StatusBadge } from '@/components/Badges';
import { issues, type Priority, type Status } from '@/data/mockData';

export default function AllIssues() {
  const [search, setSearch] = useState('');
  const [filterPriority, setFilterPriority] = useState<Priority | ''>('');
  const [filterStatus, setFilterStatus] = useState<Status | ''>('');
  const [filterCategory, setFilterCategory] = useState('');

  const categories = [...new Set(issues.map(i => i.category))];

  const filtered = issues.filter(i => {
    if (search && !i.id.toLowerCase().includes(search.toLowerCase()) && !i.category.toLowerCase().includes(search.toLowerCase()) && !i.userName.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterPriority && i.priority !== filterPriority) return false;
    if (filterStatus && i.status !== filterStatus) return false;
    if (filterCategory && i.category !== filterCategory) return false;
    return true;
  });

  return (
    <AdminLayout>
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">All Issues</h2>

        {/* Filters */}
        <div className="bg-card rounded-lg border p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by ID, category, or name..." className="w-full pl-9 pr-3 py-2 rounded-md border bg-background text-sm focus:ring-2 focus:ring-primary focus:outline-none" />
          </div>
          <select value={filterPriority} onChange={e => setFilterPriority(e.target.value as Priority | '')} className="px-3 py-2 rounded-md border bg-background text-sm">
            <option value="">All Priorities</option>
            <option>High</option><option>Medium</option><option>Low</option><option>Very Low</option>
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as Status | '')} className="px-3 py-2 rounded-md border bg-background text-sm">
            <option value="">All Statuses</option>
            <option>Submitted</option><option>Verified</option><option>Assigned</option><option>Work In Progress</option><option>Resolved</option>
          </select>
          <select value={filterCategory} onChange={e => setFilterCategory(e.target.value)} className="px-3 py-2 rounded-md border bg-background text-sm">
            <option value="">All Categories</option>
            {categories.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>

        {/* Table */}
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted">
                <th className="text-left p-3 font-medium text-muted-foreground">Ticket ID</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Image</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Category</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground">User</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Department</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Date</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(issue => (
                <tr key={issue.id} className="border-b hover:bg-muted/50 transition-colors">
                  <td className="p-3 font-mono text-xs font-semibold text-primary">{issue.id}</td>
                  <td className="p-3"><div className="h-10 w-10 rounded bg-muted flex items-center justify-center text-[8px] text-muted-foreground">IMG</div></td>
                  <td className="p-3">{issue.category}</td>
                  <td className="p-3"><PriorityBadge priority={issue.priority} /></td>
                  <td className="p-3"><StatusBadge status={issue.status} /></td>
                  <td className="p-3">{issue.userName}</td>
                  <td className="p-3 text-xs">{issue.department}</td>
                  <td className="p-3 text-xs text-muted-foreground">{issue.date}</td>
                  <td className="p-3">
                    <Link to={`/issues/${issue.id}`} className="px-3 py-1 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:opacity-90">View</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <p className="p-8 text-center text-muted-foreground">No issues found.</p>}
        </div>
      </div>
    </AdminLayout>
  );
}
