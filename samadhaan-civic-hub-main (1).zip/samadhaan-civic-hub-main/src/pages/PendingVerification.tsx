import { useState } from 'react';
import AdminLayout from '@/components/AdminLayout';
import { PriorityBadge } from '@/components/Badges';
import { issues } from '@/data/mockData';
import { MapPin, Check, X, AlertTriangle } from 'lucide-react';

export default function PendingVerification() {
  const pending = issues.filter(i => i.status === 'Submitted');

  return (
    <AdminLayout>
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">Pending Verification</h2>
        <p className="text-sm text-muted-foreground">{pending.length} issues awaiting verification</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pending.map(issue => (
            <div key={issue.id} className="bg-card rounded-lg border overflow-hidden">
              <div className="h-32 bg-muted flex items-center justify-center text-muted-foreground text-sm">Image</div>
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-semibold text-primary">{issue.id}</span>
                  <PriorityBadge priority={issue.priority} />
                </div>
                <p className="text-sm font-medium text-foreground">{issue.category}</p>
                <p className="text-xs text-muted-foreground line-clamp-2">{issue.description}</p>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" />{issue.address}
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 rounded-md bg-gov-green text-primary-foreground text-xs font-medium flex items-center justify-center gap-1 hover:opacity-90"><Check className="h-3 w-3" />Verify</button>
                  <button className="flex-1 py-2 rounded-md bg-destructive text-destructive-foreground text-xs font-medium flex items-center justify-center gap-1 hover:opacity-90"><X className="h-3 w-3" />Reject</button>
                  <button className="flex-1 py-2 rounded-md bg-saffron text-primary-foreground text-xs font-medium flex items-center justify-center gap-1 hover:opacity-90"><AlertTriangle className="h-3 w-3" />Fake</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {pending.length === 0 && <p className="text-center text-muted-foreground py-12">No pending issues.</p>}
      </div>
    </AdminLayout>
  );
}
