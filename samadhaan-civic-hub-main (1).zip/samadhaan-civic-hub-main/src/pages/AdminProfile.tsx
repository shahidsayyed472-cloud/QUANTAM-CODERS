import { useState } from 'react';
import AdminLayout from '@/components/AdminLayout';
import { User, Mail, Lock, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AdminProfile() {
  const [name, setName] = useState('Admin User');
  const [email, setEmail] = useState('admin@samadhaan.gov.in');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  return (
    <AdminLayout>
      <div className="max-w-xl space-y-6">
        <h2 className="text-2xl font-bold text-foreground">Admin Profile Settings</h2>

        <div className="bg-card rounded-lg border p-6 space-y-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-16 w-16 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xl font-bold">AD</div>
            <div>
              <p className="font-semibold text-foreground">{name}</p>
              <p className="text-xs text-muted-foreground">System Administrator</p>
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-1"><User className="h-4 w-4" />Admin Name</label>
            <input value={name} onChange={e => setName(e.target.value)} className="w-full px-3 py-2 rounded-md border bg-background text-sm" />
          </div>
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-1"><Mail className="h-4 w-4" />Email</label>
            <input value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 rounded-md border bg-background text-sm" />
          </div>
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-1"><Lock className="h-4 w-4" />Change Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="New password" className="w-full px-3 py-2 rounded-md border bg-background text-sm" />
          </div>

          <div className="flex gap-3 pt-2">
            <button className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:opacity-90">Save Changes</button>
            <button onClick={() => navigate('/login')} className="px-4 py-2 rounded-md bg-destructive text-destructive-foreground text-sm font-medium flex items-center gap-2 hover:opacity-90"><LogOut className="h-4 w-4" />Logout</button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
