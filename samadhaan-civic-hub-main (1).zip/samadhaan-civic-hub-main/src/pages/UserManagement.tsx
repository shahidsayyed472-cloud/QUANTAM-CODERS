import { useState } from 'react';
import AdminLayout from '@/components/AdminLayout';
import { users } from '@/data/mockData';

export default function UserManagement() {
  const [userList, setUserList] = useState(users);

  const toggleActive = (id: string) => {
    setUserList(prev => prev.map(u => u.id === id ? { ...u, active: !u.active } : u));
  };

  return (
    <AdminLayout>
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">User Management</h2>
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted">
                <th className="text-left p-3 font-medium text-muted-foreground">Name</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Email</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Phone</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Tickets</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Action</th>
              </tr>
            </thead>
            <tbody>
              {userList.map(user => (
                <tr key={user.id} className="border-b hover:bg-muted/50">
                  <td className="p-3 font-medium">{user.name}</td>
                  <td className="p-3 text-xs text-muted-foreground">{user.email}</td>
                  <td className="p-3 text-xs">{user.phone}</td>
                  <td className="p-3 text-center font-semibold">{user.totalTickets}</td>
                  <td className="p-3">
                    <button onClick={() => toggleActive(user.id)} className={`px-3 py-1 rounded-full text-xs font-medium ${user.active ? 'bg-gov-green/20 text-gov-green' : 'bg-destructive/10 text-destructive'}`}>
                      {user.active ? 'Active' : 'Banned'}
                    </button>
                  </td>
                  <td className="p-3">
                    <button className="px-3 py-1 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:opacity-90">View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
