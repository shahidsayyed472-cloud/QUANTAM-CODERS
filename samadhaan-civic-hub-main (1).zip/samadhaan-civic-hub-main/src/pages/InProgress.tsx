import { Link } from 'react-router-dom';
import AdminLayout from '@/components/AdminLayout';
import { PriorityBadge, StatusBadge } from '@/components/Badges';
import { issues } from '@/data/mockData';

export default function InProgress() {
  const inProgress = issues.filter(i => i.status === 'Work In Progress');

  return (
    <AdminLayout>
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">In Progress</h2>
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted">
                <th className="text-left p-3 font-medium text-muted-foreground">Ticket ID</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Category</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Department</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Action</th>
              </tr>
            </thead>
            <tbody>
              {inProgress.map(issue => (
                <tr key={issue.id} className="border-b hover:bg-muted/50">
                  <td className="p-3 font-mono text-xs font-semibold text-primary">{issue.id}</td>
                  <td className="p-3">{issue.category}</td>
                  <td className="p-3">{issue.department}</td>
                  <td className="p-3"><PriorityBadge priority={issue.priority} /></td>
                  <td className="p-3"><StatusBadge status={issue.status} /></td>
                  <td className="p-3"><Link to={`/issues/${issue.id}`} className="px-3 py-1 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:opacity-90">Update</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
          {inProgress.length === 0 && <p className="p-8 text-center text-muted-foreground">No in-progress issues.</p>}
        </div>
      </div>
    </AdminLayout>
  );
}
