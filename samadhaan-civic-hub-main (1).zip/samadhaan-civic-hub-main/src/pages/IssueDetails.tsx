import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, User, Mail, Phone, Calendar, MessageSquare } from 'lucide-react';
import AdminLayout from '@/components/AdminLayout';
import { PriorityBadge, StatusBadge } from '@/components/Badges';
import { issues, departments, statusSteps, type Priority, type Status } from '@/data/mockData';

export default function IssueDetails() {
  const { id } = useParams();
  const issue = issues.find(i => i.id === id);

  const [priority, setPriority] = useState<Priority>(issue?.priority || 'Low');
  const [status, setStatus] = useState<Status>(issue?.status || 'Submitted');
  const [department, setDepartment] = useState(issue?.department || '');
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState(issue?.comments || []);

  if (!issue) return <AdminLayout><p className="text-center text-muted-foreground py-12">Issue not found.</p></AdminLayout>;

  const currentStep = statusSteps.indexOf(status as typeof statusSteps[number]);

  const addComment = () => {
    if (!comment.trim()) return;
    setComments([...comments, { author: 'Admin', text: comment, date: new Date().toISOString().split('T')[0] }]);
    setComment('');
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-5xl">
        <div className="flex items-center gap-3">
          <Link to="/issues" className="p-2 rounded-md hover:bg-muted"><ArrowLeft className="h-4 w-4" /></Link>
          <div>
            <h2 className="text-xl font-bold text-foreground">{issue.id}</h2>
            <p className="text-xs text-muted-foreground">{issue.category}</p>
          </div>
        </div>

        {/* Header Controls */}
        <div className="bg-card rounded-lg border p-4 flex flex-wrap gap-4 items-end">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Priority</label>
            <select value={priority} onChange={e => setPriority(e.target.value as Priority)} className="px-3 py-2 rounded-md border bg-background text-sm">
              <option>High</option><option>Medium</option><option>Low</option><option>Very Low</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as Status)} className="px-3 py-2 rounded-md border bg-background text-sm">
              {statusSteps.map(s => <option key={s}>{s}</option>)}
              <option>Rejected</option><option>Fake</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Department</label>
            <select value={department} onChange={e => setDepartment(e.target.value)} className="px-3 py-2 rounded-md border bg-background text-sm">
              {departments.map(d => <option key={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:opacity-90">Update Status</button>
            <button className="px-4 py-2 rounded-md bg-saffron text-primary-foreground text-sm font-medium hover:opacity-90">Update Priority</button>
            <button className="px-4 py-2 rounded-md bg-gov-green text-primary-foreground text-sm font-medium hover:opacity-90">Assign Dept</button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-4">
            {/* Image */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-3">Issue Images</h3>
              <div className="h-48 bg-muted rounded-md flex items-center justify-center text-muted-foreground text-sm">Image Preview Placeholder</div>
            </div>
            {/* Description */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">Category & Description</h3>
              <PriorityBadge priority={priority} />
              <p className="text-sm text-foreground mt-3">{issue.description}</p>
            </div>
            {/* Location */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">Location</h3>
              <div className="h-40 bg-muted rounded-md flex items-center justify-center text-muted-foreground text-sm mb-2">Map Placeholder</div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />{issue.address}
              </div>
            </div>
            {/* Status Timeline */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Status Timeline</h3>
              <div className="flex items-center gap-2">
                {statusSteps.map((step, i) => (
                  <div key={step} className="flex items-center gap-2 flex-1">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${i <= currentStep ? 'bg-gov-green text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>{i + 1}</div>
                    <span className={`text-[10px] hidden md:block ${i <= currentStep ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>{step}</span>
                    {i < statusSteps.length - 1 && <div className={`h-0.5 flex-1 ${i < currentStep ? 'bg-gov-green' : 'bg-muted'}`} />}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {/* User Info */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-3">User Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2"><User className="h-4 w-4 text-muted-foreground" />{issue.userName}</div>
                <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-muted-foreground" />{issue.userEmail}</div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-muted-foreground" />{issue.userPhone}</div>
              </div>
            </div>
            {/* Timestamp */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-2">Timestamp</h3>
              <div className="flex items-center gap-2 text-sm"><Calendar className="h-4 w-4 text-muted-foreground" />{issue.date}</div>
              <p className="text-xs text-muted-foreground mt-1">{issue.address}</p>
            </div>
            {/* Comments */}
            <div className="bg-card rounded-lg border p-4">
              <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2"><MessageSquare className="h-4 w-4" />Admin Comments</h3>
              <div className="space-y-2 mb-3 max-h-48 overflow-y-auto">
                {comments.length === 0 && <p className="text-xs text-muted-foreground">No comments yet.</p>}
                {comments.map((c, i) => (
                  <div key={i} className="bg-muted rounded-md p-2">
                    <p className="text-xs font-medium text-foreground">{c.author}</p>
                    <p className="text-xs text-muted-foreground">{c.text}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">{c.date}</p>
                  </div>
                ))}
              </div>
              <textarea value={comment} onChange={e => setComment(e.target.value)} placeholder="Add a comment..." className="w-full px-3 py-2 rounded-md border bg-background text-sm focus:ring-2 focus:ring-primary focus:outline-none resize-none" rows={2} />
              <button onClick={addComment} className="mt-2 w-full py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium hover:opacity-90">Add Comment</button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
