import { useState } from 'react';
import AdminLayout from '@/components/AdminLayout';
import { departments as initialDepts } from '@/data/mockData';
import { Plus, Pencil, Trash2, X } from 'lucide-react';

export default function DepartmentManagement() {
  const [depts, setDepts] = useState(initialDepts);
  const [editing, setEditing] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', contact: '', email: '', phone: '' });

  const startEdit = (id: string) => {
    const d = depts.find(x => x.id === id);
    if (d) { setForm({ name: d.name, contact: d.contact, email: d.email, phone: d.phone }); setEditing(id); setShowAdd(false); }
  };

  const save = () => {
    if (editing) {
      setDepts(prev => prev.map(d => d.id === editing ? { ...d, ...form } : d));
      setEditing(null);
    } else {
      setDepts(prev => [...prev, { id: Date.now().toString(), ...form }]);
      setShowAdd(false);
    }
    setForm({ name: '', contact: '', email: '', phone: '' });
  };

  const remove = (id: string) => setDepts(prev => prev.filter(d => d.id !== id));

  return (
    <AdminLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Department Management</h2>
          <button onClick={() => { setShowAdd(true); setEditing(null); setForm({ name: '', contact: '', email: '', phone: '' }); }} className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2 hover:opacity-90"><Plus className="h-4 w-4" />Add Department</button>
        </div>

        {(showAdd || editing) && (
          <div className="bg-card rounded-lg border p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">{editing ? 'Edit' : 'Add'} Department</h3>
              <button onClick={() => { setShowAdd(false); setEditing(null); }} className="p-1 hover:bg-muted rounded"><X className="h-4 w-4" /></button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Department Name" className="px-3 py-2 rounded-md border bg-background text-sm" />
              <input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })} placeholder="Contact Person" className="px-3 py-2 rounded-md border bg-background text-sm" />
              <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="Email" className="px-3 py-2 rounded-md border bg-background text-sm" />
              <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone" className="px-3 py-2 rounded-md border bg-background text-sm" />
            </div>
            <button onClick={save} className="mt-3 px-4 py-2 rounded-md bg-gov-green text-primary-foreground text-sm font-medium hover:opacity-90">Save</button>
          </div>
        )}

        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted">
                <th className="text-left p-3 font-medium text-muted-foreground">Department</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Contact Person</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Email</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Phone</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {depts.map(d => (
                <tr key={d.id} className="border-b hover:bg-muted/50">
                  <td className="p-3 font-medium">{d.name}</td>
                  <td className="p-3">{d.contact}</td>
                  <td className="p-3 text-xs text-muted-foreground">{d.email}</td>
                  <td className="p-3 text-xs">{d.phone}</td>
                  <td className="p-3 flex gap-2">
                    <button onClick={() => startEdit(d.id)} className="p-1.5 rounded hover:bg-muted"><Pencil className="h-4 w-4 text-primary" /></button>
                    <button onClick={() => remove(d.id)} className="p-1.5 rounded hover:bg-muted"><Trash2 className="h-4 w-4 text-destructive" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
