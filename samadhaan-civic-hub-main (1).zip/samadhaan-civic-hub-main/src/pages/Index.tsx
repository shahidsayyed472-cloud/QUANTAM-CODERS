import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { FileText, AlertTriangle, Clock, CheckCircle, XCircle, Building2, ArrowRight } from 'lucide-react';
import AdminLayout from '@/components/AdminLayout';
import { issues } from '@/data/mockData';

const stats = [
  { title: 'Total Issues', value: issues.length, icon: FileText, color: 'bg-primary text-primary-foreground' },
  { title: 'High Priority', value: issues.filter(i => i.priority === 'High').length, icon: AlertTriangle, color: 'bg-priority-high text-primary-foreground' },
  { title: 'In Progress', value: issues.filter(i => i.status === 'Work In Progress').length, icon: Clock, color: 'bg-saffron text-primary-foreground' },
  { title: 'Resolved', value: issues.filter(i => i.status === 'Resolved').length, icon: CheckCircle, color: 'bg-gov-green text-primary-foreground' },
  { title: 'Rejected / Fake', value: issues.filter(i => ['Rejected', 'Fake'].includes(i.status)).length, icon: XCircle, color: 'bg-destructive text-destructive-foreground' },
  { title: 'Departments', value: 5, icon: Building2, color: 'bg-primary text-primary-foreground' },
];

const priorityData = [
  { name: 'High', value: issues.filter(i => i.priority === 'High').length },
  { name: 'Medium', value: issues.filter(i => i.priority === 'Medium').length },
  { name: 'Low', value: issues.filter(i => i.priority === 'Low').length },
  { name: 'Very Low', value: issues.filter(i => i.priority === 'Very Low').length },
];
const PIE_COLORS = ['#e74c3c', '#FF9933', '#f1c40f', '#138808'];

const categoryData = [
  { name: 'Electrical', count: 2 }, { name: 'Road', count: 2 }, { name: 'Garbage', count: 2 },
  { name: 'Water', count: 1 }, { name: 'Sewage', count: 1 }, { name: 'Parks', count: 1 }, { name: 'Signboard', count: 1 },
];

const trendData = Array.from({ length: 30 }, (_, i) => ({
  day: `Day ${i + 1}`,
  issues: Math.floor(Math.random() * 8) + 1,
}));

const quickLinks = [
  { title: 'Pending Verification', path: '/pending', count: issues.filter(i => i.status === 'Submitted').length },
  { title: 'Assigned Issues', path: '/assigned', count: issues.filter(i => i.status === 'Assigned').length },
  { title: 'High Priority', path: '/issues?priority=High', count: issues.filter(i => i.priority === 'High').length },
];

export default function Dashboard() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Dashboard</h2>
          <p className="text-sm text-muted-foreground">Overview of civic issues across all departments</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {stats.map(s => (
            <div key={s.title} className="bg-card rounded-lg border p-4 saffron-accent">
              <div className="flex items-center justify-between mb-2">
                <div className={`h-8 w-8 rounded-md ${s.color} flex items-center justify-center`}>
                  <s.icon className="h-4 w-4" />
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.title}</p>
            </div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="bg-card rounded-lg border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-4">Issues by Priority</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={priorityData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" label={({ name }) => name}>
                  {priorityData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card rounded-lg border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-4">Issues by Category</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#0A3D62" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card rounded-lg border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-4">Issues Trend (30 days)</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} interval={6} />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="issues" stroke="#FF9933" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {quickLinks.map(l => (
            <Link key={l.path} to={l.path} className="bg-card rounded-lg border p-4 hover:shadow-md transition-shadow flex items-center justify-between group">
              <div>
                <p className="text-sm font-semibold text-foreground">{l.title}</p>
                <p className="text-2xl font-bold text-primary">{l.count}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-saffron transition-colors" />
            </Link>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
