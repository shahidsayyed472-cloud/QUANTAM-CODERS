import AdminLayout from '@/components/AdminLayout';
import { PriorityBadge } from '@/components/Badges';
import { issues } from '@/data/mockData';

export default function ResolvedIssues() {
  const resolved = issues.filter(i => i.status === 'Resolved');

  return (
    <AdminLayout>
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">Resolved Issues</h2>
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted">
                <th className="text-left p-3 font-medium text-muted-foreground">Ticket ID</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Before</th>
                <th className="text-left p-3 font-medium text-muted-foreground">After</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Resolution</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Resolved Date</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
              </tr>
            </thead>
            <tbody>
              {resolved.map(issue => (
                <tr key={issue.id} className="border-b hover:bg-muted/50">
                  <td className="p-3 font-mono text-xs font-semibold text-primary">{issue.id}</td>
                  <td className="p-3"><div className="h-12 w-16 rounded bg-muted flex items-center justify-center text-[8px] text-muted-foreground">Before</div></td>
                  <td className="p-3"><div className="h-12 w-16 rounded bg-gov-green/20 flex items-center justify-center text-[8px] text-gov-green">After</div></td>
                  <td className="p-3 text-xs">{issue.comments.length > 0 ? issue.comments[issue.comments.length - 1].text : 'Resolved successfully'}</td>
                  <td className="p-3 text-xs text-muted-foreground">{issue.date}</td>
                  <td className="p-3"><PriorityBadge priority={issue.priority} /></td>
                </tr>
              ))}
            </tbody>
          </table>
          {resolved.length === 0 && <p className="p-8 text-center text-muted-foreground">No resolved issues.</p>}
        </div>
      </div>
    </AdminLayout>
  );
}
