import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import Login from "./pages/Login.tsx";
import AllIssues from "./pages/AllIssues.tsx";
import IssueDetails from "./pages/IssueDetails.tsx";
import PendingVerification from "./pages/PendingVerification.tsx";
import AssignedIssues from "./pages/AssignedIssues.tsx";
import InProgress from "./pages/InProgress.tsx";
import ResolvedIssues from "./pages/ResolvedIssues.tsx";
import UserManagement from "./pages/UserManagement.tsx";
import DepartmentManagement from "./pages/DepartmentManagement.tsx";
import AdminProfile from "./pages/AdminProfile.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/issues" element={<AllIssues />} />
          <Route path="/issues/:id" element={<IssueDetails />} />
          <Route path="/pending" element={<PendingVerification />} />
          <Route path="/assigned" element={<AssignedIssues />} />
          <Route path="/in-progress" element={<InProgress />} />
          <Route path="/resolved" element={<ResolvedIssues />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/departments" element={<DepartmentManagement />} />
          <Route path="/profile" element={<AdminProfile />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
