export type Priority = 'High' | 'Medium' | 'Low' | 'Very Low';
export type Status = 'Submitted' | 'Verified' | 'Assigned' | 'Work In Progress' | 'Resolved' | 'Rejected' | 'Fake';

export interface Issue {
  id: string;
  category: string;
  description: string;
  priority: Priority;
  status: Status;
  userName: string;
  userEmail: string;
  userPhone: string;
  department: string;
  date: string;
  location: string;
  address: string;
  comments: { author: string; text: string; date: string }[];
}

export const departments = [
  { id: '1', name: 'Public Works', contact: 'Rajesh Kumar', email: 'pwd@gov.in', phone: '+91 11 2345 6780' },
  { id: '2', name: 'Water Supply', contact: 'Sunita Sharma', email: 'water@gov.in', phone: '+91 11 2345 6781' },
  { id: '3', name: 'Electricity Board', contact: 'Arun Gupta', email: 'electricity@gov.in', phone: '+91 11 2345 6782' },
  { id: '4', name: 'Sanitation', contact: 'Meena Devi', email: 'sanitation@gov.in', phone: '+91 11 2345 6783' },
  { id: '5', name: 'Parks & Gardens', contact: 'Vikram Singh', email: 'parks@gov.in', phone: '+91 11 2345 6784' },
];

export const issues: Issue[] = [
  { id: 'SAM-2024-001', category: 'Electrical Issues', description: 'Broken street light near sector 15 main road causing safety concern at night.', priority: 'High', status: 'Submitted', userName: 'Amit Verma', userEmail: 'amit@email.com', userPhone: '+91 98765 43210', department: 'Electricity Board', date: '2024-03-15', location: '28.6139,77.2090', address: 'Sector 15, Main Road, New Delhi', comments: [] },
  { id: 'SAM-2024-002', category: 'Road Damage', description: 'Large pothole on MG Road causing accidents. Multiple complaints from residents.', priority: 'Medium', status: 'Verified', userName: 'Priya Singh', userEmail: 'priya@email.com', userPhone: '+91 98765 43211', department: 'Public Works', date: '2024-03-14', location: '28.6329,77.2195', address: 'MG Road, Sector 22, Gurugram', comments: [{ author: 'Admin', text: 'Verified on site visit.', date: '2024-03-15' }] },
  { id: 'SAM-2024-003', category: 'Garbage', description: 'Garbage pile-up near community park entrance. Foul smell affecting residents.', priority: 'Low', status: 'Assigned', userName: 'Ravi Kumar', userEmail: 'ravi@email.com', userPhone: '+91 98765 43212', department: 'Sanitation', date: '2024-03-13', location: '28.6448,77.2167', address: 'Community Park, Sector 10, Noida', comments: [] },
  { id: 'SAM-2024-004', category: 'Water Leakage', description: 'Severe water pipeline burst near market area. Water wastage and road flooding.', priority: 'High', status: 'Work In Progress', userName: 'Suman Devi', userEmail: 'suman@email.com', userPhone: '+91 98765 43213', department: 'Water Supply', date: '2024-03-12', location: '28.6508,77.2340', address: 'Market Area, Karol Bagh, Delhi', comments: [{ author: 'Admin', text: 'Team dispatched.', date: '2024-03-13' }] },
  { id: 'SAM-2024-005', category: 'Park Maintenance', description: 'Broken benches and overgrown grass in children park.', priority: 'Very Low', status: 'Resolved', userName: 'Neha Gupta', userEmail: 'neha@email.com', userPhone: '+91 98765 43214', department: 'Parks & Gardens', date: '2024-03-10', location: '28.6692,77.4538', address: 'Children Park, Sector 5, Ghaziabad', comments: [{ author: 'Admin', text: 'Maintenance completed.', date: '2024-03-14' }] },
  { id: 'SAM-2024-006', category: 'Sewage Overflow', description: 'Sewage overflowing on main street causing health hazard.', priority: 'Medium', status: 'Assigned', userName: 'Karan Mehta', userEmail: 'karan@email.com', userPhone: '+91 98765 43215', department: 'Sanitation', date: '2024-03-11', location: '28.6353,77.2250', address: 'Main Street, Lajpat Nagar, Delhi', comments: [] },
  { id: 'SAM-2024-007', category: 'Signboard Repair', description: 'Damaged traffic signboard at intersection.', priority: 'Very Low', status: 'Submitted', userName: 'Divya Joshi', userEmail: 'divya@email.com', userPhone: '+91 98765 43216', department: 'Public Works', date: '2024-03-16', location: '28.6280,77.2189', address: 'Intersection, Connaught Place, Delhi', comments: [] },
  { id: 'SAM-2024-008', category: 'Electrical Issues', description: 'Exposed electrical wiring near school zone. Extremely dangerous.', priority: 'High', status: 'Verified', userName: 'Rahul Pandey', userEmail: 'rahul@email.com', userPhone: '+91 98765 43217', department: 'Electricity Board', date: '2024-03-15', location: '28.6105,77.2303', address: 'School Zone, Saket, Delhi', comments: [{ author: 'Admin', text: 'Urgent: dispatching team.', date: '2024-03-15' }] },
  { id: 'SAM-2024-009', category: 'Garbage', description: 'Open dumping ground near residential area.', priority: 'Low', status: 'Work In Progress', userName: 'Anita Rao', userEmail: 'anita@email.com', userPhone: '+91 98765 43218', department: 'Sanitation', date: '2024-03-09', location: '28.6517,77.1856', address: 'Residential Area, Dwarka, Delhi', comments: [] },
  { id: 'SAM-2024-010', category: 'Road Damage', description: 'Road cave-in after heavy rains near bus stop.', priority: 'Medium', status: 'Submitted', userName: 'Vijay Thakur', userEmail: 'vijay@email.com', userPhone: '+91 98765 43219', department: 'Public Works', date: '2024-03-16', location: '28.6785,77.3154', address: 'Bus Stop, Vasundhara, Ghaziabad', comments: [] },
];

export const users = [
  { id: '1', name: 'Amit Verma', email: 'amit@email.com', phone: '+91 98765 43210', totalTickets: 3, active: true },
  { id: '2', name: 'Priya Singh', email: 'priya@email.com', phone: '+91 98765 43211', totalTickets: 5, active: true },
  { id: '3', name: 'Ravi Kumar', email: 'ravi@email.com', phone: '+91 98765 43212', totalTickets: 2, active: true },
  { id: '4', name: 'Suman Devi', email: 'suman@email.com', phone: '+91 98765 43213', totalTickets: 1, active: false },
  { id: '5', name: 'Neha Gupta', email: 'neha@email.com', phone: '+91 98765 43214', totalTickets: 4, active: true },
  { id: '6', name: 'Karan Mehta', email: 'karan@email.com', phone: '+91 98765 43215', totalTickets: 2, active: true },
];

export const priorityColors: Record<Priority, string> = {
  'High': 'priority-high',
  'Medium': 'priority-medium',
  'Low': 'priority-low',
  'Very Low': 'priority-verylow',
};

export const statusSteps = ['Submitted', 'Verified', 'Assigned', 'Work In Progress', 'Resolved'] as const;
